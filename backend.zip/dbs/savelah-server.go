package main

import (
	"net/http"

	"github.com/tzumtzum/T2020_Blue3/savelah-server/controllers"
)

func main() {

	c := controllers.ControllerInit()
	r := c.RouterInit()

	err := http.ListenAndServe(":7000", r)
	if err != nil {
		c.App.Log.WithError(err).Fatal("Server Error")
	}

}
