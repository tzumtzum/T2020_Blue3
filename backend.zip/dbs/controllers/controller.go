package controllers

import (
	"github.com/go-chi/chi"

	"github.com/tzumtzum/T2020_Blue3/savelah-server/application"
	"github.com/tzumtzum/T2020_Blue3/savelah-server/models"
)

type Controller struct {
	App *application.Application
	Mod *models.Model
}

const (
	APIURL      = "/api"

	// Restful API parameters
	Email       = "email"
	Password    = "password"
)

func ControllerInit() *Controller {

    c := &Controller{}
	app := application.AppInit()
	c.App = app
	c.Mod = models.ModelInit(app)

	return c
}

// RouterInit initialises the router and defines the endpoints for each handler
func (c *Controller) RouterInit() *chi.Mux {

	r := chi.NewRouter()

	r.Route(APIURL+"/user", func(r chi.Router) {
	})

	r.Get("/api/sample", c.SampleHandler)

	r.Get("/api/expenses/{id}/{month}",c.GetExpensesHandler)

	return r

}

