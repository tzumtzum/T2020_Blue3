package controllers

import (
	"encoding/json"
	"fmt"
	"net/http"
	"io/ioutil"
	"github.com/go-chi/chi"
)


type TransactionRequest struct {
	AccountId    string `json:"account_id"`
	TransactionId string `json:"transaction_id"`
	Type string `json:"type"`
	Amount  string `json:"amount"`
	Date string `json:"date"`
	Tag string `json:"tag"`
	Referencenumber string `json:"referenceNumber"`
}


func (c *Controller) SampleHandler(w http.ResponseWriter, r *http.Request) {

	fmt.Println("Sample Handler")

	response := &Response{
		Status:  "success",
		Message: "The sample handler works!",
	}

	w.WriteHeader(http.StatusOK)
	resBytes, _ := json.MarshalIndent(response, "", "  ")
	w.Write(resBytes)

}

func (c *Controller) GetExpensesHandler(w http.ResponseWriter, r *http.Request) {


	custID := chi.URLParam(r, "id")
	mon := chi.URLParam(r, "month")

   var period string
	switch mon {
	case "jan":
		period = "from=01-01-2019&to=31-01-2019"
	case "feb" :
		period = "from=01-02-2018&to=28-02-2019"
	case "mar" :
		period = "from=01-03-2018&to=31-03-2019"
	case "apr" :
		period = "from=01-04-2018&to=30-04-2019"
	case "may" :
		period = "from=01-05-2018&to=31-05-2019"
	case "jun":
		period = "from=01-06-2018&to=30-06-2019"
	case "jul" :
		period = "from=01-07-2018&to=31-07-2019"
	case "aug":
		period = "from=01-08-2018&to=31-08-2019"
	case "sep":
		period = "from=01-09-2018&to=30-09-2019"
	case "oct":
		period = "from=01-10-2018&to=31-10-2019"
	case "nov":
		period = "from=01-11-2018&to=30-11-2019"
	case "dec":
		period = "from=01-12-2018&to=31-12-2019"
	}

    //url  := "http://techtrek-api-gateway.ap-southeast-1.elasticbeanstalk.com/transactions/10?from=01-01-2018&to=02-01-2019"
	baseURL := "http://techtrek-api-gateway.ap-southeast-1.elasticbeanstalk.com/transactions/" 
	url := baseURL +custID +"?" +period

    client := &http.Client{}
	req, err := http.NewRequest("GET",url,nil)
	if err != nil {
		c.App.Log.WithError(err).Error("Error in reading body of request")
		return
	}
	req.Header.Set("identity","Group3")
	req.Header.Set("token","41ae9f00-7900-4b4a-a5e9-8d8482d1e89e")
	resp, err := client.Do(req)
	if err != nil {
		c.App.Log.WithError(err).Error("Error in headers of request")
	}
	
	body, err := ioutil.ReadAll(resp.Body)
	if err != nil {
		c.App.Log.WithError(err).Error("Error reading params")
		return
	}

	var param []TransactionRequest
	err = json.Unmarshal(body, &param)
	if err != nil {
		c.App.Log.WithError(err).Error("Unable to unmarshal body")
	}

	response := &Response{
		Status:  "success",
		Message: "Retrieving transaction",
		Data: param,
	}


	w.WriteHeader(http.StatusOK)
	w.Header().Set("Access-Control-Allow-Origin", "*")
	resBytes, _ := json.MarshalIndent(response, "", "  ")
	w.Write(resBytes)

}
