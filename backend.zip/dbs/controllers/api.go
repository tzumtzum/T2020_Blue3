package controllers

import (
	"encoding/json"
	"net/http"
)

type Response struct {
	Status  string      `json:"status"` // "success" or "error"
	Message string      `json:"message"`
	Data    interface{} `json:"data"`
}

const (
	MessageInternalServerError = "Sorry for the interruption! The team has been alerted that one part of the " +
		"server has exploded!"
	StatusBadRequest          = "Bad Request due to cilent error"
	StatusOK                  = "Success Response"
	StatusUnprocessableEntity = "Unable to process request due to semantic problems in payload"

	// User login
	MessageUserSignUpMissingParams       = "Missing parameters for user signup."
	MessageUserSignUpEmailTaken          = "Email has been taken."
	MessageUserLoginMissingParams        = "Missing parameters for user login."
	MessageUserLoginInvalidEmailPassword = "Invalid email/password combination."

	MessageUserInvalidEmailFormat    = "Invalid email format. Reason: %s."
	MessageUserInvalidPasswordFormat = "Invalid password format. Reason: %s."
	MessageUserInvalidAccountType    = "Invalid account type."
)

// ErrorInternalServer takes in a custom error config and sends it
// back to the api caller
func (r *Response) Error(w http.ResponseWriter, code int, message string, data interface{}) {

	r.Status = "error"
	r.Message = message
	r.Data = data

	w.WriteHeader(code)
	resBytes, _ := json.MarshalIndent(r, "", "  ")
	w.Write(resBytes)

}

// ErrorInternalServer sends an Internal server error - 500
// back to the api caller
func (r *Response) ErrorInternalServer(w http.ResponseWriter, data interface{}) {

	r.Status = "error"
	r.Message = MessageInternalServerError
	r.Data = data

	w.WriteHeader(http.StatusInternalServerError)
	resBytes, _ := json.MarshalIndent(r, "", "  ")
	w.Write(resBytes)

}

// ErrorBadRequest sends an Bad request error - 400
// back to the api caller
func (r *Response) ErrorBadRequest(w http.ResponseWriter, data interface{}) {

	r.Status = "error"
	r.Message = StatusBadRequest
	r.Data = data

	w.WriteHeader(http.StatusBadRequest)
	resBytes, _ := json.MarshalIndent(r, "", "  ")
	w.Write(resBytes)

}

// ErrorUnprocessableEntity sends an Unprocessable entity error - 422
// back to the api caller
func (r *Response) ErrorUnprocessableEntity(w http.ResponseWriter, data interface{}) {

	r.Status = "error"
	r.Message = StatusUnprocessableEntity
	r.Data = data

	w.WriteHeader(http.StatusUnprocessableEntity)
	resBytes, _ := json.MarshalIndent(r, "", "  ")
	w.Write(resBytes)

}

//  StatusOK  sends an StatusOK - 200
// back to the api caller
func (r *Response) SucessResponse(w http.ResponseWriter, data interface{}) {

	r.Status = "success"
	r.Message = StatusOK
	r.Data = data

	w.WriteHeader(http.StatusOK)
	resBytes, _ := json.MarshalIndent(r, "", "  ")
	w.Write(resBytes)

}
