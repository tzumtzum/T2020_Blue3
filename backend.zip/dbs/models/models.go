package models

import (
	"github.com/tzumtzum/T2020_Blue3/savelah-server/application"
)

// Define person struct
type User struct {
	userName string `json:"username"`
	password string `json:"password"`
	custID   string `json:"custID"`
	accID 	 string `json:"accID"`
	accNo	 string `json:"accNo"`
}

// Define period struct
type Period struct {
	month string
}

type Model struct {
	App *application.Application
}

func GetCustDetails(custId string) {
	
}

func ModelInit(app *application.Application)  *Model {

	m := &Model{app}
	userInt()
	return m	
}

func userInt() {
	user0 := User{"limzeyang","1234","1","10" ,"588967151"}
	user1 := User{"marytan","1234","2","74" ,"5490723483"}
	user2 := User{"prasannaghali","1234","3","32" ,"120781322"}	

}


