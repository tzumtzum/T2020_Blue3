package application

import (
	"github.com/sirupsen/logrus"
)

type Application struct {
	Log          *logrus.Logger
}


func AppInit() *Application {

	app := &Application{}
	app.Log = logrus.New()

	return app
}

